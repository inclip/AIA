import { BrowserRouter as Routes, Route } from "react-router-dom";
import Apifetch from "./components/pages/api_fetch";
import { Fragment } from "react";
 
function App() {
  return (
      <Fragment>    
        <Routes>
              <div className="container">
                <div className="app-content">
                  <Route path="/Api" exact component={Apifetch} />
                </div>
              </div>
        </Routes>
      </Fragment>
  );
}
 
export default App;