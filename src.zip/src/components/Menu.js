import React, { Components } from "react";
import { Link } from "react-router-dom";
import './components/Menu.css'

class Menu extends Components {
    render() {
        return(
            <div>
                <header className="header">
                    <ul className="Menu">
                        <li><Link to="/api">Get Api</Link></li>
                    </ul>
                </header>
            </div>
        )
    }
}