// import express
import express from "express";
// import controllers
import { fetchApi } from "../controllers/fetchApiController.js";
 
    // express router
const router = express.Router();
 
// Route get All Products
router.get('/Api', fetchApi);
 
// export router
export default router;