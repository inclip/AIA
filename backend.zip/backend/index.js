



//import express
import express from "express";
// import routes
import route from "./routes/index.js";
//import cors
import cors from "cors";
// construct express function
const app = express();
 
// middleware 
app.use(cors());
app.use(express.json());
app.use('/Api',route);

 
app.listen(5000, ()=> console.log('Server up and running...'));