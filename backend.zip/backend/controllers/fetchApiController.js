// import models
import fetchApi from "../components/fetchApi.js";
 

// function get All Products
export const fetchApi = async (req, res) => {
    try {
        const apps = await fetchApi.find();
        res.json(apps);
    } catch (error) {
        res.status(500).json({message: error.message});
    }
     
}
 
 
