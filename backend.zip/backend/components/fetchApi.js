import React, { Component } from 'react'
import CardPost from './components/card_post';
 
const urlAPI = 'https://jsonplaceholder.typicode.com/posts';
 
class api_fetch extends Component {
    constructor(props) {
        super(props);
        this.state = {
            arrypost: []
        }
    }
 
    componentDidMount() {
        this.GetDataAPi()
        //this.GetDataByAxios()
    }
 
    GetDataAPi() {
 
        fetch(urlAPI).then(res => {
            if (res.status === 200)
                return res.json()
        }).then(resdata => {
            console.log(resdata)
            this.setState({
                arrypost: resdata
            })
        })
    }
 
    render() {
        return (
            <div className="container">
                fatch data from Api JsonPlaceHolder
                {
                    this.state.arrypost.map(function (data) {
                        return <CardPost key={data.id} title={data.title} conten={data.body} />
                    })
 
                }
            </div>
        )
    }
}
 
export default api_fetch;