import React, { Component } from 'react'
import img from './imgpost.png'
import './public/css/cardstyle.css'
import './css/cardstyle.css'
 
class cardpost extends Component {
    render() {
        return (
            <div>
                <div className="column">
                    <div className="card">
                        <img src={img} />
                        <div className="card-title">
                            <h4>{this.props.title}</h4>
                        </div>
                        <div className="card-content">
                            {this.props.content}
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}
export default cardpost;