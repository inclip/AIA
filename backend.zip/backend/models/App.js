import React, { useState, useEffect } from 'react'
import './App.css';

function App() {
  const url = 'https://jsonplaceholder.typicode.com/photos'

  const [photos, setPhotos] = useState([])

  const getDataPhotos = async () => {
    const response = await fetch('https://jsonplaceholder.typicode.com/photos')
    const dataku = await response.json()
    const photos = dataku.slice(0, 8)
    setPhotos(photos)
  }

  useEffect(() => {
    getDataPhotos()
  }, [])

  return (
    <div>
      <h3>List Photos</h3>
      {photos.map((photo) => {
        return (
          <p key={photo.id}>
            {photo.title}
            <img src='{thumbnailUrl}' />
            {photo.url}
            
          </p>
        )
      })}
    </div>
  );
}

export default App;